flatpak install --system com.github.tchx84.Flatseal -y
flatpak install --system com.synology.SynologyDrive -y
flatpak install --system net.cozic.joplin_desktop -y
